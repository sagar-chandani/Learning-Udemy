// accept an integer N and return all the prime numbers
// from 2 up to (but not including) n. Return the prime
// numbers as an array. Use two queues to implement the
// sieve of Eratosthenes.
function primesUpToN(n) {

}