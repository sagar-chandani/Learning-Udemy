const minefield = [
    ['*', '*',  '',  ''],
    ['*', '*',  '',  ''],
    ['',  '',   '*', ''],
    ['',  '',   '',  ''],
];

// the output should print the following
// **20
// **31
// 23*1
// 0111
function minesweeper(minefield) {

}
