Arrays vs Lists

Array
  - has a fixed size
  - you create an array by specifying
    it's size
  - you can write to an array
    with: a[index] = value
  - you can read from an array
    with x = a[index]

List
  - has no fixed size
  - is often created empty, then
    values are added to it
  - you can add something to a list
    with l.add(value)
  - you can read something from a list
    with x = l.get(index)
