aa = [1, 2, 3, 4, 5]
aa.push(99)
console.log("aa:", aa)
aa.pop()
aa.pop()
console.log("aa:", aa)
