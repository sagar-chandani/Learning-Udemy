// Modify l1 so the end of l1 points to the root of l2
function concat(l1, l2) {

}