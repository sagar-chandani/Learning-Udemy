// Accepts a list and manipulates the list so it becomes reversed.
// Do not create a new list. Manipulate the original list.
function reverse(list) {

}