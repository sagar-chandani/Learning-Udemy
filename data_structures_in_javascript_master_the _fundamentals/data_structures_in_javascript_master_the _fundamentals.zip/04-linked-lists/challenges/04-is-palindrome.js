// Accept a linked list with a .root property
// where each node has one letter in it's data
// property. Return whether or not the string the
// whole list represents is a palindrome.
function isPalindrome(list) {

}