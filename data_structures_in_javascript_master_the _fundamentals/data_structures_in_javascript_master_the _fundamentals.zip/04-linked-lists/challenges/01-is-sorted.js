// Write a function that accepts a LinkedList with one .root
// property and returns true if the list is sorted in ascending order.
// Bonus: return true if it's either ascending or descending.
function isSorted(list) {

}