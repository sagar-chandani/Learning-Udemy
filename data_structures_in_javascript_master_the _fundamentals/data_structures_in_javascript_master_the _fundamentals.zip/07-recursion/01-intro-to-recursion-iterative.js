function main() {
    let players = getPlayers();
    startGame(players);
}

function getPlayers() {
    
}

function startGame(players) {

}

main()