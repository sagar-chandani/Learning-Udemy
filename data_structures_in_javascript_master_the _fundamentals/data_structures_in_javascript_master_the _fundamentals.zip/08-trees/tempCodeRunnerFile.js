        let leftMin = this._min(node.left)
